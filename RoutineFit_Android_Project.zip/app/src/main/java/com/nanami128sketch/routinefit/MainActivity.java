package com.nanami128sketch.routinefit;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Insets;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JsPromptResult;
import android.webkit.JsResult;
import android.webkit.WebResourceError;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.webkit.WebViewAssetLoader;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final int PICK_JSON = 501;
    private static final int SAVE_JSON = 502;
    private static final String LOCAL_ORIGIN = "https://appassets.androidplatform.net/";
    private WebView web;
    private ValueCallback<Uri[]> fileCallback;
    private String pendingJson;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private WebViewAssetLoader loader;

    public final class RoutineFitBridge {
        @JavascriptInterface public void setKeepScreenOn(boolean enabled) {
            runOnUiThread(() -> {
                if (enabled) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            });
        }
        @JavascriptInterface public void saveBackup(String json) {
            if (json == null || json.length() > 12_000_000) return;
            runOnUiThread(() -> {
                pendingJson = json;
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                intent.putExtra(Intent.EXTRA_TITLE, "routinefit-backup.json");
                try { startActivityForResult(intent, SAVE_JSON); }
                catch (ActivityNotFoundException ex) { Toast.makeText(MainActivity.this,"파일 저장 앱을 찾을 수 없습니다.",Toast.LENGTH_LONG).show(); }
            });
        }
    }
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(0xff0d1720);
        getWindow().setNavigationBarColor(0xff0d1720);
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(0xff0d1720);
        if(Build.VERSION.SDK_INT >= 30) {
            root.setOnApplyWindowInsetsListener((v,insets) -> {
                Insets bars=insets.getInsets(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                v.setPadding(bars.left,bars.top,bars.right,bars.bottom);
                return insets;
            });
        }
        web = new WebView(this);
        root.addView(web,new FrameLayout.LayoutParams(-1,-1));
        setContentView(root);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setMediaPlaybackRequiresUserGesture(true);
        settings.setSupportMultipleWindows(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        WebView.setWebContentsDebuggingEnabled(BuildConfig.DEBUG);
        loader=new WebViewAssetLoader.Builder().addPathHandler("/assets/",new WebViewAssetLoader.AssetsPathHandler(this)).build();
        web.addJavascriptInterface(new RoutineFitBridge(),"RoutineFitNative");
        web.setWebViewClient(new WebViewClient(){
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest req) {
                return loader.shouldInterceptRequest(req.getUrl());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest req) {
                String u=req.getUrl().toString();
                if(u.startsWith(LOCAL_ORIGIN+"assets/"))return false;
                if(req.isForMainFrame())openExternal(req.getUrl());
                return true;
            }
        });
        web.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onShowFileChooser(WebView view,ValueCallback<Uri[]> callback, FileChooserParams params) {
                if(fileCallback!=null) fileCallback.onReceiveValue(null);
                fileCallback=callback;
                Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                try { startActivityForResult(intent,PICK_JSON); }
                catch(Exception e){fileCallback=null;callback.onReceiveValue(null);return false;}
                return true;
            }
            @Override public boolean onCreateWindow(WebView view,boolean isDialog,boolean isUserGesture,android.os.Message resultMsg) {
                if(!isUserGesture)return false;
                WebView popup=new WebView(MainActivity.this);
                popup.setWebViewClient(new WebViewClient(){
                    @Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest r) {
                        openExternal(r.getUrl());handler.postDelayed(popup::destroy,400);return true;
                    }
                });
                WebView.WebViewTransport transport=(WebView.WebViewTransport)resultMsg.obj;
                transport.setWebView(popup);resultMsg.sendToTarget();
                return true;
            }
        });
        // Application package assets are served from the secure appassets origin; NOT github.io.
        // Data from an existing Chrome PWA must be exported and imported by the user.
        web.loadUrl(LOCAL_ORIGIN+"assets/index.html");
    }
    private void openExternal(Uri uri) {
        try {
            if(!"https".equalsIgnoreCase(uri.getScheme()))return;
            startActivity(new Intent(Intent.ACTION_VIEW,uri));
        } catch (Exception e) {Toast.makeText(this,"외부 사이트를 열 수 없습니다.",Toast.LENGTH_SHORT).show();}
    }
    @Override protected void onActivityResult(int req,int res,Intent data) {
        super.onActivityResult(req,res,data);
        if(req==PICK_JSON){
            if(fileCallback!=null){
                Uri[] chosen=res==RESULT_OK&&data!=null&&data.getData()!=null ? new Uri[]{data.getData()} : null;
                fileCallback.onReceiveValue(chosen);fileCallback=null;
            }
        } else if(req==SAVE_JSON){
            if(res==RESULT_OK&&data!=null&&data.getData()!=null&&pendingJson!=null){
                try(OutputStream o=getContentResolver().openOutputStream(data.getData())){
                    if(o==null)throw new Exception("output null");
                    o.write(pendingJson.getBytes(StandardCharsets.UTF_8));
                    Toast.makeText(this,"운동 기록 백업 저장 완료",Toast.LENGTH_SHORT).show();
                }catch(Exception ex){Toast.makeText(this,"백업 저장 실패: 다시 시도해 주세요.",Toast.LENGTH_LONG).show();}
            }
            pendingJson=null;
        }
    }
    @Override public void onBackPressed() {
        if(web.canGoBack()) web.goBack();
        else new AlertDialog.Builder(this).setTitle("루틴핏 종료").setMessage("앱을 종료해도 저장된 운동 기록은 유지됩니다. 종료하시겠습니까?")
            .setNegativeButton("계속 운동",(d,w)->{}).setPositiveButton("종료",(d,w)->finish()).show();
    }
    @Override protected void onDestroy() {
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if(web!=null){web.removeJavascriptInterface("RoutineFitNative");web.destroy();web=null;}
        super.onDestroy();
    }
}
